#!/bin/bash

while read mLine
do
  echo $mLine
done < ~/Downloads/data/C.in 
