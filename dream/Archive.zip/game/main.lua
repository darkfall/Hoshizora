
function add(a, b, coll)
    if (a==leon and b==block) or (a==block and b==leon) then
		onGround=true
	end
end

function persist(a, b, coll)
    
end

function rem(a, b, coll)
    if (a==leon and b==block) or (a==block and b==leon) then
		onGround=false
	end
end

function result(a, b, coll)
    
end

function love.load()
	love.filesystem.load('dream_lib.lua')()
	love.filesystem.load('dream_class.lua')()
	love.filesystem.load('preset.lua')()
	scene = Scene:new()
	scene:__init({x1=0,x2=0,y1=2000,y2=2000})
	actor = StaticImageActor:new()
	actor:__init({image = 'cloud.jpg',x=0,y=0,r=0,sx=1,sy=1,ox=506/2,oy=334/2})
	actor2 = SequenceActor:new()
	actor2:__init({image = 'cloud.jpg',x=0,y=0,r=0,sx=1,sy=1,ox=32,oy=32,stand={1,{0,0,64,64,500,500},{64,0,64,64,500,500}}})
	--local t = {{0,0,64,64,64,64},{64,0,64,64,64,64}}
	--local seq = {tt=1,step=0.5,xy=t} 
	--actor = SequenceActor:new({image = 'cloud.jpg',x=0,y=0,r=0,sx=1,sy=1,ox=0,oy=0,sequence={stand=seq} })
	leon = Character:new()
	leon:__init({x=100,y=0,r=0,w=64,h=64,actor = actor2,m=100})
	scene:addObject(leon)
	block = Block:new()
	block:__init({x=100, y=400,w=506,h=334,r=0,m=0,actor=actor})
	scene:addObject(block)
	scene.world:setCallbacks(add, persist, rem, result)
end

function love.update(dt)
	x,y = leon.body:getLinearVelocity()
	if love.keyboard.isDown('left') then leon.body:setLinearVelocity(-80,y)
	elseif love.keyboard.isDown('right') then leon.body:setLinearVelocity(80,y)
	else leon.body:setLinearVelocity(0,y) end
	if love.keyboard.isDown('up') and onGround then
		leon.body:applyImpulse(0,-100,leon.body:getWorldCenter())
	end
	scene:update(dt)
end

function love.draw()
	scene:draw()
end